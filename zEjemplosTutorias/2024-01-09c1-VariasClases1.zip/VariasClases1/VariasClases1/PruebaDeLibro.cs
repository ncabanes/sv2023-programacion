﻿// Mejora la clase "Libro": Main ya no estará en 
// ella, sino en una "PruebaDeLibro". Crea 
// ambas en Visual Studio.

class PruebaDeLibro
{
    static void Main()
    {
        Libro l1 = new Libro();
        l1.SetAutor("Stephen King");
        l1.SetAutor("It");
        l1.SetUbicacion("Est1 Bal2");

        l1.MostrarDetalles();

        Libro l2 = new Libro();
        l2.SetAutor("Stephen King");
        l2.SetAutor("Carrie");
        l2.SetUbicacion("Est1 Bal2");

        l2.MostrarDetalles();
    }
}

// Autor: It
// Título:
// Ubic: Est1 Bal2
// Autor: Carrie
// Título:
// Ubic: Est1 Bal2
