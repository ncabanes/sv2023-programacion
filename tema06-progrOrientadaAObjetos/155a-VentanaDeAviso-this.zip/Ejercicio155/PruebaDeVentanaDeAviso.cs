﻿/*155. Mejora el ejercicio anterior (154), para que haya un segundo constructor
 * en VentanaDeAviso, que sólo sólo reciba los valores de X, de Y y del Texto),
 * y que se apoye en el constructor más detallado, empleando "this" para prefijar
 * la anchura a 40 y la altura a 5. */

// Noelia (...)

class PruebaDeVentanaDeAviso
{
    static void Main()
    {
        VentanaDeAviso[] v = new VentanaDeAviso[3];

        v[0] = new VentanaDeAviso(40, 12, 30, 5,
            "Ventana sin rellenar");
        v[0].X = 15;
        v[0].Y = 8;

        v[1] = new VentanaDeAvisoRellena(50, 6, 15, 5,
            "Ventana rellena");

        v[2] = new VentanaDeAviso(50, 12, "Otra sin rellenar"); // ventana this

        v[0].Mostrar();
        v[1].Mostrar();
        v[2].Mostrar();
    }
}
