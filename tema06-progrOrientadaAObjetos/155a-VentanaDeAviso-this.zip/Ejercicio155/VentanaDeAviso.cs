﻿using System;

class VentanaDeAviso
{
    public VentanaDeAviso(int xInicial, int yInicial,
        int ancho, int alto, string textoMostrar)
    {
        X = xInicial;
        Y = yInicial;
        Anchura = ancho;
        Altura = alto;
        Texto = textoMostrar;
    }

    public VentanaDeAviso(int xInicial, int yInicial, string textoMostrar)
        : this (xInicial, yInicial, 40, 5, textoMostrar)    
    {
    }

    public int X { get; set; }
    public int Y { get; set; }
    public int Anchura { get; set; }
    public int Altura { get; set; }
    public string Texto { get; set; }

    public virtual void Mostrar()
    {
        for (int fila = 0; fila < Altura; fila++)
        {
            for (int columna = 0; columna < Anchura; columna++)
            {
                if (fila == 0 || fila == Altura - 1
                    || columna == 0 || columna == Anchura - 1)
                {
                    Console.SetCursorPosition(X + columna, Y + fila);
                    Console.Write("*");
                }
            }
        }
        Console.SetCursorPosition(
            X + Anchura / 2 - Texto.Length / 2,
            Y + Altura / 2);
        Console.WriteLine(Texto);
    }
}
