﻿/*
131.Crea, desde Visual Studio, una clase llamada "VentanaDeAviso",
cuyos atributos (privados) serán las coordenadas x e y de comienzo 
(números enteros), la anchura y la altura (también enteros) y el texto 
que va a mostrar esa ventana de aviso. Crea "getters" y "setters" que 
permitan cambiar el valor de los atributos. Tendrá también un método 
"Mostrar", que muestre la ventana en pantalla con el mensaje centrado 
en ella (puedes dejar este método vacío, o bien tratar de implementarlo 
usando Console.SetCursorPosition). Crea, en un segundo fichero fuente,
una clase "PruebaDeVentanaDeAviso", que tendrá un "Main" capaz de crear 
dos ventanas en distintas posiciones, con distintos tamaños y distintos 
mensajes, y los mostrará en pantalla (no es importante si el método 
"Mostrar" no lo has llegado a desarrollar y realmente no se ve nada en 
pantalla). Entrega todo el proyecto de Visual Studio, comprimido en un 
fichero ZIP.
*/

// Iván (...), retoques por Nacho

class PruebaDeVentanaDeAviso
{
    static void Main()
    {
        VentanaDeAviso v = new VentanaDeAviso();

        v.SetX(40);
        v.SetY(12);
        v.SetAltura(5);
        v.SetAnchura(30);
        v.SetTexto("Base de datos analizada");

        v.Mostrar();

        v.SetX(50);
        v.SetY(6);
        v.SetAltura(5);
        v.SetAnchura(15);
        v.SetTexto("Bienvenido");

        v.Mostrar();
    }
}

