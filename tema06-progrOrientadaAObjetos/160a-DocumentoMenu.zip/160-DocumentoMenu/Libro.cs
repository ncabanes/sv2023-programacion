﻿using System;

class Libro : Documento
{
    protected char tapa;

    public char GetTapa() { return tapa; }
    public void SetTapa(string tapa) 
    {
        if (tapa != null) this.tapa = Convert.ToChar(tapa.ToUpper()[0]); 
    }
    public Libro(string titulo, string autor, int paginas, string ubicacion,
        string tapa) : base(titulo, autor, paginas, ubicacion) 
    {
        this.tapa = Convert.ToChar(tapa.ToUpper()[0]);
    }

    public override string ToString()
    {
        return base.ToString() + ", Portada = " + tapa; 
    }
}
