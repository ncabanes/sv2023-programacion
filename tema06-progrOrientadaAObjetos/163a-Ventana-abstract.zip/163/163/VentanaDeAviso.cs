﻿using System;

abstract class VentanaDeAviso
{
    public VentanaDeAviso(int xInicial, int yInicial,
        int ancho, int alto, string textoMostrar)
    {
        X = xInicial;
        Y = yInicial;
        Anchura = ancho;
        Altura = alto;
        Texto = textoMostrar;
    }

    public VentanaDeAviso(int xInicial, int yInicial, string textoMostrar)
        : this(xInicial, yInicial, 40, 5, textoMostrar)
    {
    }

    public int X { get; set; }
    public int Y { get; set; }
    public int Anchura { get; set; }
    public int Altura { get; set; }
    public string Texto { get; set; }

    public abstract void Mostrar();
}