﻿// Iván (...)

class PruebaDeVentanaDeAviso
{
    static void Main()
    {
        VentanaDeAviso[] v = new VentanaDeAvisoConBorde[2];

        v[0] = new VentanaDeAvisoConBorde(40, 12, 30, 5,
            "Ventana sin rellenar");
        v[0].X = 15;
        v[0].Y = 8;

        v[1] = new VentanaDeAvisoConBorde(50, 12, "Otra sin rellenar"); // ventana this

        v[0].Mostrar();
        v[1].Mostrar();

        VentanaDeAviso[] vr = new VentanaDeAvisoRellena[1];

        vr[0] = new VentanaDeAvisoRellena(50, 6, 15, 5, "Ventana rellena");
        vr[0].Mostrar();
        
        
    }
}