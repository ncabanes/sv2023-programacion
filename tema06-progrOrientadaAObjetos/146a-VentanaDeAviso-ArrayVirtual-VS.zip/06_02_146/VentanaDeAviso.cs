﻿using System;

class VentanaDeAviso
{
    protected int x, y, anchura, altura;
    protected string texto;

    public VentanaDeAviso() { }

    public VentanaDeAviso(int xInicial, int yInicial,
        int ancho, int alto, string textoMostrar)
    {
        x = xInicial;
        y = yInicial;
        anchura = ancho;
        altura = alto;
        texto = textoMostrar;
    }

    public int GetX() { return x; }
    public int GetY() { return y; }
    public int GetAnchura() { return anchura; }
    public int GetAltura() { return altura; }
    public string GetTexto() { return texto; }

    public void SetX(int valor) { x = valor; }
    public void SetY(int valor) { y = valor; }
    public void SetAnchura(int valor) { anchura = valor; }
    public void SetAltura(int valor) { altura = valor; }
    public void SetTexto(string valor) { texto = valor; }

    public virtual void Mostrar()
    {
        for (int fila = 0; fila < altura; fila++)
        {
            for (int columna = 0; columna < anchura; columna++)
            {
                if (fila == 0 || fila == altura - 1
                    || columna == 0 || columna == anchura - 1)
                {
                    Console.SetCursorPosition(x + columna, y + fila);
                    Console.Write("*");
                }
            }
        }
        Console.SetCursorPosition(
            x + anchura / 2 - texto.Length / 2,
            y + altura / 2);
        Console.WriteLine(texto);
    }
}
