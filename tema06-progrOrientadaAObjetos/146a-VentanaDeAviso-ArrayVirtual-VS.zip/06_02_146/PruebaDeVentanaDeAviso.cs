﻿/* 146. Crea una variante del ejercicio anterior (145), en la que Dibujar sea
 * "virtual" en la clase base y "override" en la clase hija. Comprueba si ahora
 * se comporta correctamente.
 * 
 * VÍCTOR (...) */

class PruebaDeVentanaDeAviso
{
    static void Main()
    {
        VentanaDeAviso[] v = new VentanaDeAviso[2];

        v[0] = new VentanaDeAviso(40, 12, 30, 5,
            "Ventana sin rellenar");
        v[1] = new VentanaDeAvisoRellena(50, 6, 15, 5,
            "Ventana rellena");

        v[0].Mostrar();
        v[1].Mostrar();
    }
}
