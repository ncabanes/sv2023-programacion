﻿using System;

class VentanaDeAvisoRellena : VentanaDeAviso
{
    public VentanaDeAvisoRellena(int xInicial, int yInicial,
        int ancho, int alto, string textoMostrar)
    {
        x = xInicial;
        y = yInicial;
        anchura = ancho;
        altura = alto;
        texto = textoMostrar;
    }

    public override void Mostrar()
    {
        Console.BackgroundColor = ConsoleColor.DarkBlue;
        for (int fila = 0; fila < altura; fila++)
        {
            for (int columna = 0; columna < anchura; columna++)
            {
                Console.SetCursorPosition(x + columna, y + fila);
                Console.Write(" ");
            }
        }
        Console.SetCursorPosition(
            x + anchura / 2 - texto.Length / 2,
            y + altura / 2);
        Console.WriteLine(texto);
        Console.BackgroundColor = ConsoleColor.Black;
    }
}
