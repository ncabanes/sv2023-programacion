﻿class SpriteTextoColor : SpriteTexto
{
    protected string color;

    public SpriteTextoColor() {}
    public SpriteTextoColor (
        int xInicial, int yInicial, char caracterInicial, 
        string colorInicial)
    {
        x = xInicial; 
        y = yInicial;
        caracter = caracterInicial;
        color = colorInicial;
    }
    
    public void Dibujar()
    {
        CambiarColor(color);
        Console.SetCursorPosition(x, y);
        Console.Write(caracter);
    }

    public void CambiarColor(string color)
    {
        if (color == "amarillo")
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
        }
        else if (color == "blanco")
        {
            Console.ForegroundColor = ConsoleColor.White;
        }
        else if (color == "cyan")
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
        }
    }
}
