﻿/* A partir de las clases "NaveEnemiga" y "NaveJugador", crea un 
programa que permita mover la nave del jugador cuando se pulsen las 
flechas del teclado, para lo que te puedes ayudar del siguiente 
fragmento de código:

ConsoleKeyInfo tecla = Console.ReadKey();
if (tecla.Key == ConsoleKey.LeftArrow)
    n.MoverIzquierda();
else if (tecla.Key == ConsoleKey.RightArrow)
    n.MoverDerecha();
else if (tecla.Key == ConsoleKey.Escape)
    salir = true;

Quizá te interese borrar la pantalla con Console.Clear(); */

// Iván (...), retoques menores por Nacho

class PruebaDeSprite
{
    static void Main()
    {
        bool salir = false;

        ConsoleColor originalColor = Console.ForegroundColor;

        NaveEnemiga ne = new NaveEnemiga(10, 5);
        NaveJugador nj = new NaveJugador(20, 20);

        while (!salir)
        {
            // Dibujamos elementos
            Console.Clear();
            ne.Dibujar();
            nj.Dibujar();

            // Y comprobamos teclas
            ConsoleKeyInfo tecla = Console.ReadKey();
            if (tecla.Key == ConsoleKey.LeftArrow)
            {
                nj.MoverIzquierda();
            }
            else if (tecla.Key == ConsoleKey.RightArrow)
            {
                nj.MoverDerecha();
            }
            else if (tecla.Key == ConsoleKey.Escape)
            {
                salir = true;
            }
        }
        Console.ForegroundColor = originalColor;
    }
}
