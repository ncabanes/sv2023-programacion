﻿class NaveEnemiga : SpriteTextoColor
{
    public NaveEnemiga(int xInicial, int yInicial) 
    {
        x = xInicial; 
        y = yInicial;
        color = "cyan";
        caracter = 'W';
    }
}
