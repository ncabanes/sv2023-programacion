﻿/* 130. Crea una nueva versión del ejercicio 129 (clase Pez, en la que cada
 * clase esté en un fichero independiente, empleando Visual Studio (o alguna
 * herramienta similar). Deberás entregar todo el proyecto de Visual Studio,
 * comprimido en un fichero ZIP.
 * 
 * VÍCTOR (...) */

using System;

class SimuladorDePecera
{
    static void Main()
    {
        Pez pescado = new Pez();

        Console.Write("Dime el nombre del pez: ");
        pescado.SetNombre(Console.ReadLine());
        Console.Write("Dime la especie del pez: ");
        pescado.SetEspecie(Console.ReadLine());


        string nombre = pescado.GetNombre();
        string especie = pescado.GetEspecie();
        Console.WriteLine(nombre);
        Console.WriteLine(especie);


        pescado.Nadar();
    }
}