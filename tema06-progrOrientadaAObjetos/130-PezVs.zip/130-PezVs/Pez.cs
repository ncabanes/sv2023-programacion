﻿using System;

class Pez
{
    private string nombre, especie;

    public string GetNombre() { return nombre; }
    public string GetEspecie() { return especie; }

    public void SetNombre(string nuevoNombre) { nombre = nuevoNombre; }
    public void SetEspecie(string nuevaEspecie) { especie = nuevaEspecie; }

    public void Nadar()
    {
        Console.WriteLine("Soy un pez de la especie " + especie + " llamado " +
            nombre + " y estoy nadando");
    }
}