﻿class Marcador
{
    public void MostrarMarcador() { }
}

