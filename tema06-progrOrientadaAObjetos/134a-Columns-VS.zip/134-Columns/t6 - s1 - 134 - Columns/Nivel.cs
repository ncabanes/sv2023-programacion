﻿class Nivel
{
    public void MostrarNivel() { }
}

