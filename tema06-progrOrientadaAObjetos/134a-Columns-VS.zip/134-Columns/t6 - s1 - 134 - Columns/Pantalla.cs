﻿class Pantalla
{
    private int coordenadasX;
    private int coordenadasY;

    public int GetCoordenadasx() { return coordenadasX; }
    public int GetCoordenadasy() { return coordenadasY; }

    public void SetNuevasCoordenadasX (int nuevaX) { coordenadasX = nuevaX; }
    public void SetNuevasCoordenadasY(int nuevaY) { coordenadasY = nuevaY; }
}

