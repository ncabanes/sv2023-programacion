﻿
class Bienvenida
{
    public void MostrarPuntuacion() { }
}
