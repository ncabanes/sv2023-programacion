﻿class Juego
{
    static void Main()
    {
        Bienvenida bienvenida = new Bienvenida();
        Partida partida = new Partida(); 
        Bloque bloque = new Bloque();
        Pantalla pantalla = new Pantalla();
        Marcador marcador= new Marcador();
        Nivel nivel = new Nivel();
    }
}

