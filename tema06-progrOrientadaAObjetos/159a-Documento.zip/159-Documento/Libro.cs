﻿class Libro : Documento
{
    private char tapa;

    public char GetTapa() { return tapa; }
    public void SetTapa(char tapa) { this.tapa = tapa; }
    public Libro(string titulo, string autor, int paginas, char tapa) 
        : base(titulo, autor, paginas) 
    {
        this.tapa = tapa;
    }

    public override string ToString()
    {
        return base.ToString() + ", Portada = " + tapa; 
    }
}

