﻿class Documento
{
    private string titulo, autor;
    private int paginas;

    public string GetTitulo() {  return titulo; }  
    public string GetAutor() {  return autor; }
    public int GetPaginas() {  return paginas; }

    public void SetTitulo(string titulo) { this.titulo = titulo; }
    public void SetAutor(string autor) { this.autor = autor; }
    public void SetPaginas(int paginas) {  this.paginas = paginas;}
    
    public Documento(string titulo, string autor, int paginas)
    {
        this.titulo = titulo;
        this.autor = autor;
        this.paginas = paginas;
    }
    public Documento(string titulo) : this (titulo, "Anónimo", 0) { }

    public override string ToString()
    {
        return "Autor = " + autor + ", Título = " + titulo + 
            ", páginas = " + paginas;
    }



}

