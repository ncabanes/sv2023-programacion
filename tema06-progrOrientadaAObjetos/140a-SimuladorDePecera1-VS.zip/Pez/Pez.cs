﻿using System;

class Pez
{
    protected string nombre, especie;
    protected byte x, y;

    public string GetNombre() { return nombre; }
    public string GetEspecie() { return especie; }
    public int GetX() { return Convert.ToInt32(x); }
    public int GetY() { return Convert.ToInt32(y); }


    public void SetNombre(string nuevoNombre) { nombre = nuevoNombre; }
    public void SetEspecie(string nuevaEspecie) { especie = nuevaEspecie; }
    public void SetX(int nuevaX) { x = (byte) nuevaX; }
    public void SetY(int nuevaY) { y = (byte) nuevaY; }

    public Pez()
    {
        nombre = "Pepe";
        especie = "salmon";
    }

    public Pez(string nuevoNombre, string nuevaEspecie, int nuevaX, int nuevaY)
    {
        nombre = nuevoNombre;
        especie = nuevaEspecie;
        x = (byte)nuevaX;
        y = (byte)nuevaY;
    }

    public void Nadar()
    {
        x++;
    }

    public void Dibujar()
    {
        Console.SetCursorPosition(x, y);
        Console.Write("><(((º>");
    }

    ~Pez()
    {
        Console.Write("Aquí acabó la vida del pez");
    }
}