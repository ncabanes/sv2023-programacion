﻿using System;

class PezMenor : Pez
{
    public PezMenor(string nuevoNombre, string nuevaEspecie, int nuevaX, int nuevaY)
    {
        nombre = nuevoNombre;
        especie = nuevaEspecie;
        x = (byte)nuevaX;
        y = (byte)nuevaY;
        haciaLaDerecha = true;
    }

    private void DibujarDerecha()
    {
        Console.SetCursorPosition(x, y);
        Console.Write("><=>");
    }

    private void DibujarIzquierda()
    {
        Console.SetCursorPosition(x, y);
        Console.Write("<=><");
    }
    
    public void Dibujar()
    {
        if (haciaLaDerecha) DibujarDerecha();
        else DibujarIzquierda();
    }
}
