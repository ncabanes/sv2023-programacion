﻿/*
141. Crea otra clase que herede de Pez (la que tú desees), y que cambie 
ligeramente el comportamiento y/o la apariencia. Haz que dos peces de clases 
distintas naden en la pantalla. Como mejora opcional, puedes hacer que su 
"imagen" cambie cuando "reboten" en un extremo de la pantalla. Por ejemplo, 
puede pasar de ser "><=>" a ser ""<=><".
*/
// Mario (...), retoques por Nacho

using System;

class SimuladorDePecera
{
    static void Main()
    {
        Pez pescado = new Pez("Juan", "sardina", 15, 15);
        PezMenor pezquenyin = new PezMenor("Pepe", "boqueron", 5, 5);

        bool salir = false;
        do
        {
            // Dibujado de pantalla
            Console.Clear();
            pescado.Dibujar();
            pezquenyin.Dibujar();

            // Comprobación de teclas
            ConsoleKeyInfo tecla = Console.ReadKey();
            if (tecla.Key == ConsoleKey.Escape)
            {
                salir = true;
            }
            
            // Movimiento de elementos
            pescado.Nadar();
            pezquenyin.Nadar();
        }
        while (!salir);
    }
}
