﻿/* 150. Crea una variante del ejercicio anterior (149), en la que 
Dibujar sea "virtual" en la clase base y "override" en la clase hija. 
Comprueba si ahora se comporta correctamente.

Julio, retoques menores por Nacho
*/

class PruebaDeSprite
{
    static void Main()
    {
        bool salir = false;

        ConsoleColor originalColor = Console.ForegroundColor;

        SpriteTexto[] spriteNave = new SpriteTexto[5];

        spriteNave[0] = new NaveEnemiga(10, 5);
        spriteNave[1] = new NaveEnemiga(12, 6);
        spriteNave[2] = new NaveEnemiga(15, 18);
        spriteNave[3] = new NaveEnemiga(18, 21);
        spriteNave[4] = new NaveJugador(5, 10);

        while (!salir)
        {
            // Dibujamos elementos
            Console.Clear();

            for (int i = 0; i < spriteNave.Length - 1; i++)
            {
                spriteNave[i].Dibujar();
            }

            spriteNave[4].Dibujar();

            // Y comprobamos teclas
            ConsoleKeyInfo tecla = Console.ReadKey();
            if (tecla.Key == ConsoleKey.LeftArrow)
            {
                spriteNave[4].MoverIzquierda();
            }
            else if (tecla.Key == ConsoleKey.RightArrow)
            {
                spriteNave[4].MoverDerecha();
            }
            else if (tecla.Key == ConsoleKey.Escape)
            {
                salir = true;
            }
        }
        Console.ForegroundColor = originalColor;
    }
}
