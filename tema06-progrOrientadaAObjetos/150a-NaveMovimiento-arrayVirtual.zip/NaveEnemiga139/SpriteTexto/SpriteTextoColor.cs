﻿using System;

class SpriteTextoColor : SpriteTexto
{
    protected string color;

    public SpriteTextoColor() { }
    public SpriteTextoColor(
        int xInicial, int yInicial, char caracterInicial,
        string colorInicial)
    {
        x = xInicial;
        y = yInicial;
        caracter = caracterInicial;
        color = CambiarColor(colorInicial);
    }
    
    public override void Dibujar()
    {
        CambiarColor(color);
        Console.SetCursorPosition(x, y);
        Console.Write(caracter);
    }

    public string CambiarColor(string color)
    {
        if (color == "amarillo")
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
        }
        if (color == "blanco")
        {
            Console.ForegroundColor = ConsoleColor.White;
        }
        if (color == "cyan")
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
        }

        return color;
    }
}
