﻿/*127. Crea una nueva versión del ejercicio 126 (segunda versión de la clase "SpriteTexto"),
 * en la que cada clase esté en un fichero independiente, empleando Visual Studio
 * (o alguna herramienta similar). Deberás entregar todo el proyecto de Visual Studio,
 * comprimido en un fichero ZIP.*/

//Noelia (...)

class PruebadeSprite
{
    static void Main()
    {
        SpriteTexto nave = new SpriteTexto();

        nave.SetX(40);
        nave.SetY(12);
        nave.SetCaracter('A');

        nave.MoverDerecha();
        nave.Dibujar();

        //nave.MoverIzquierda();
        //nave.Dibujar();
    }
}
