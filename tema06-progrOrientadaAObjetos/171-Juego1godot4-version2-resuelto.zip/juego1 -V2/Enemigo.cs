using Godot;
using System;

public partial class Enemigo : Area2D
{
	private Vector2 velocidad;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		AnimatedSprite2D animacion = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
		animacion.Play();
		velocidad = new Vector2(150, 0);
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		Position += (float) delta * velocidad;
		if (Position.X > 900)
		{
			velocidad = new Vector2(-150, 0);
		}
		if(Position.X < 100){
			velocidad = new Vector2(+150,0);
		}
	}
	
	private void _on_area_entered(Area2D area)
	{
		// Replace with function body.
		GD.Print("pum");
	}
}



