﻿class ElementoGrafico
{
    protected int x;
    protected int y;

    public ElementoGrafico() { }

    public ElementoGrafico(int nuevaX, int nuevaY)
    {
        x = nuevaX;
        y = nuevaY;
    }

    public void Mostrar()
    {
    }
}

