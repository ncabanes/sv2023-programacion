﻿class Pantalla
{
    private int coordenadasX;
    private int coordenadasY;

    public Pantalla() { }

    public Pantalla(int nuevaX, int nuevaY)
    {
        coordenadasX = nuevaX;
        coordenadasY = nuevaY;
    }

    public int GetCoordenadasX() { return coordenadasX; }
    public int GetCoordenadasY() { return coordenadasY; }

    public void SetNuevasCoordenadasX(int nuevaX) { coordenadasX = nuevaX; }
    public void SetNuevasCoordenadasY(int nuevaY) { coordenadasY = nuevaY; }
}

class Partida
{
    public void Lanzar()
    {
        Pantalla pantalla = new Pantalla(42, 12);
        Marcador marcador = new Marcador();
        Nivel nivel = new Nivel();
        Bloque bloque = new Bloque(10, 8, 1, 2, 3);

        bool salir = false;

        do
        {
            Console.Clear();
            bloque.Dibujar();

            ConsoleKeyInfo tecla = Console.ReadKey();


            if (tecla.Key == ConsoleKey.LeftArrow)
            {
                bloque.MoverIzquierda();
            }
            else if (tecla.Key == ConsoleKey.RightArrow)
            {
                bloque.MoverDerecha();
            }
            else if (tecla.Key == ConsoleKey.DownArrow)
            {
                bloque.MoverAbajo();
            }
            else if (tecla.Key == ConsoleKey.Escape)
                salir = true;

        }
        while (!salir);
    }

    public void Finalizar() { }
}