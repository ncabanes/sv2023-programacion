﻿class Bienvenida
{
    public void Mostrar() { }
}