﻿class Juego
{
    static void Main()
    {
        Bienvenida bienvenida = new Bienvenida();
        bienvenida.Mostrar();

        Partida partida = new Partida();
        partida.Lanzar();
    }
}