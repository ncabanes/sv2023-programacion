﻿class Marcador : ElementoGrafico
{
}

