﻿class Nivel : ElementoGrafico
{
    public void AumentarVelocidad() { }
}
