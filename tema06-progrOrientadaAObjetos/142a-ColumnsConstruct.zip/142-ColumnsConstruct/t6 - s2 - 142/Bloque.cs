﻿class Bloque : ElementoGrafico
{
    private int colorCuadrado1;
    private int colorCuadrado2;
    private int colorCuadrado3;

    public Bloque(int nuevaX, int nuevaY,
        int nuevoColor1, int nuevoColor2, int nuevoColor3)
    {
        x = nuevaX;
        y = nuevaY;
        colorCuadrado1 = nuevoColor1;
        colorCuadrado2 = nuevoColor2;
        colorCuadrado3 = nuevoColor3;
    }

    public int GetcolorCuadrado1() { return colorCuadrado1; }
    public int GetcolorCuadrado2() { return colorCuadrado2; }
    public int GetcolorCuadrado3() { return colorCuadrado3; }

    public void setNuevoColorCuadrado1(int nuevoColor1) { colorCuadrado1 = nuevoColor1; }
    public void setNuevoColorCuadrado2(int nuevoColor2) { colorCuadrado2 = nuevoColor2; }
    public void setNuevoColorCuadrado3(int nuevoColor3) { colorCuadrado3 = nuevoColor3; }

    public void Mover() { }

    public void MoverIzquierda() { x--; }
    public void MoverDerecha() { x++; }
    public void MoverAbajo() { y++; }

    public void Dibujar()
    {
        Console.SetCursorPosition(x, y);
        Console.ForegroundColor = ConsoleColor.Red;
        Console.Write("*");

        Console.SetCursorPosition(x, y + 1);
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.Write("*");

        Console.SetCursorPosition(x, y + 2);
        Console.ForegroundColor = ConsoleColor.Green;
        Console.Write("*");

        Console.ForegroundColor = ConsoleColor.White;
    }
}
