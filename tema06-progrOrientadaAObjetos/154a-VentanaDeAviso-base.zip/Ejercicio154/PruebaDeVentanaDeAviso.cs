﻿/*154.A partir de la "solución oficial" del ejercicio 148 (VentanaDeAviso y
 * VentanaDeAvisoRellena, con propiedades compactas), crea una versión en la 
 * que no haya constructor vacío en la clase VentanaDeAviso, sino que la
 * clase VentanaDeAvisoRellena utilice la palabra "base" donde sea necesario. */

//Noelia (...)

class PruebaDeVentanaDeAviso
{
    static void Main()
    {
        VentanaDeAviso[] v = new VentanaDeAviso[2];

        v[0] = new VentanaDeAviso(40, 12, 30, 5,
            "Ventana sin rellenar");
        v[0].X = 15;
        v[0].Y = 8;

        v[1] = new VentanaDeAvisoRellena(50, 6, 15, 5,
            "Ventana rellena");

        v[0].Mostrar();
        v[1].Mostrar();
    }
}
