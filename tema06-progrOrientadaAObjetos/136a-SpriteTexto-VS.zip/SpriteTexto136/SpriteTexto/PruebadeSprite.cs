﻿/* Crea una nueva versión de la clase "SpriteTexto" (ejercicio 127), 
con un constructor que permita asignar valores a sus tres atributos. 
Adapta el programa de prueba para que use ese constructor.*/

//Iván (...)

class PruebadeSprite
{
    static void Main()
    {
        SpriteTexto nave = new SpriteTexto(40, 12, 'A');

        nave.MoverDerecha();
        nave.Dibujar();
    }
}
