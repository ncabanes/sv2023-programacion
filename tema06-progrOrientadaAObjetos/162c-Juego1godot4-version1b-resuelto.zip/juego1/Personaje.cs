using Godot;
using System;

public partial class Personaje : Area2D
{
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		if (Input.IsActionPressed("ui_right"))
		{
			Position += new Vector2(200 * (float) delta, 0);
		}
		if(Input.IsActionPressed("ui_left"))
		{
			Position += new Vector2(-200 * Convert.ToSingle(delta),0);
		}
		if(Input.IsActionPressed("ui_up"))
		{
			Position += new Vector2(0 ,-200* Convert.ToSingle(delta));
		}
		if(Input.IsActionPressed("ui_down"))
		{
			Position += new Vector2(0 ,200* Convert.ToSingle(delta));
		}
	}
}
