﻿/*
143. Crea una clase "VentanaDeAvisoRellena", que herede de "VentanaDeAviso", 
pero no dibuje un rectángulo hueco, sino uno que tenga un cierto carácter (por 
ejemplo "·") en cada una de sus casillas. Si te atreves a intentarlo, como 
alternativa, puedes hacer que todas las casillas que forman la ventana tengan 
un color de fondo distinto, por ejemplo con "Console.BackgroundColor = 
ConsoleColor.DarkBlue;" y luego volviendo a dejar el color por defecto con 
"Console.BackgroundColor = ConsoleColor.Black;"
*/

// Iván (...), retoques menores por Nacho

class PruebaDeVentanaDeAviso
{
    static void Main()
    {
        VentanaDeAviso v = new VentanaDeAviso(40, 12, 30, 5, 
            "Base de datos analizada");
        v.Mostrar();
        
        VentanaDeAviso v2 = new VentanaDeAviso(50, 6, 15, 5, "Bienvenido");
        v2.Mostrar();

        VentanaDeAvisoRellena vr = new VentanaDeAvisoRellena(
            10, 10, 20, 10, "Hasta luego");
        vr.Mostrar();
    }
}
