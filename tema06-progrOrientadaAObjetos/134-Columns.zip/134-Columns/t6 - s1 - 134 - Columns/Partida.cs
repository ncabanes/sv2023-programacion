﻿class Partida
{
    public void Lanzar() { }
    public void Finalizar() { }
}

