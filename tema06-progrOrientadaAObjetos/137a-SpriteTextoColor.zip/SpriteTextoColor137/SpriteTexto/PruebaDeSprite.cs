﻿/* 137. Crea una clase "SpriteTextoColor", que será un subtipo de 
"SpriteTexto", y tendrá un nuevo atributo llamado "color", de tipo 
"string". En esta primera versión, ese atributo podrá tener los valores 
"blanco" (que cambiará el color del texto haciendo 
"Console.ForegroundColor = ConsoleColor.White;"), "cyan" (que hará 
"Console.ForegroundColor = ConsoleColor.Cyan;") y "amarillo" (que usará 
"Console.ForegroundColor = ConsoleColor.Yellow;"). Añade también un 
constructor a esta clase, que permita fijar, además de los tres 
atributos anteriores, el color. Los atributos de "SpriteTexto" pasarán 
a ser "protected". Pruéba la nueva clase desde Main de modo que 
dibujes, en las coordenadas (30, 8), un carácter "X" en color amarillo.
*/

//Iván (...)

class PruebaDeSprite
{
    static void Main()
    {
        ConsoleColor originalColor = Console.ForegroundColor;

        SpriteTexto nave = new SpriteTexto(40, 12, 'A');

        nave.MoverDerecha();
        nave.Dibujar();

        SpriteTextoColor spt = new SpriteTextoColor(30, 8, 'X', "amarillo");

        spt.Dibujar();

        Console.ForegroundColor = originalColor;
    }
}
