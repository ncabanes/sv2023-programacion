using Godot;
using System;

public partial class ObjetoQueCae : Area2D
{
	private Vector2 velocidad;
	
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		Position = new Vector2( GD.Randi() % 1000, -20);
		velocidad = new Vector2(0, 150);
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		Position += velocidad * (float) delta;
		if (Position.Y > 600)
			QueueFree();
	}
}
