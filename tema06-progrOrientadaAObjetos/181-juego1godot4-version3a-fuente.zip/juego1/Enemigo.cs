using Godot;
using System;

public partial class Enemigo : Area2D
{
	private int velocidad;
	private escena_de_juego juego;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		AnimatedSprite2D animacion = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
		animacion.Play();
		velocidad = 50;
		juego = GetNode<escena_de_juego>("/root/EscenaDeJuego");
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		Vector2 posPersonaje = juego.GetPosicionPersonaje();
		Vector2 distancia = posPersonaje - Position;
		Position += distancia.Normalized() * velocidad * (float) delta;
		/*
		Position += (float) delta * velocidad;
		if (Position.X > 900)
		{
			velocidad = new Vector2(-150, 0);
		}
		if(Position.X < 100){
			velocidad = new Vector2(+150,0);
		}
		*/
	}
}
