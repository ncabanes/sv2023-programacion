﻿/* 147. Crea una variante del ejercicio anterior (146), empleando propiedades
 * (en formato largo) en vez de "getters" y "setters" convencionales. Haz que
 * los atributos sean privados, en vez de protegidos, de modo que la clase
 * VentanaDeAvisoRellena use las propiedades, en vez de los atributos. Además,
 * desde Main, cambia la X del primer rectángulo usando propiedades.
 * 
 * VÍCTOR (...), retoques menores por Nacho */

class PruebaDeVentanaDeAviso
{
    static void Main()
    {
        VentanaDeAviso[] v = new VentanaDeAviso[2];

        v[0] = new VentanaDeAviso(40, 12, 30, 5,
            "Ventana sin rellenar");
        v[0].X = 10;

        v[1] = new VentanaDeAvisoRellena(50, 6, 15, 5,
            "Ventana rellena");

        v[0].Mostrar();
        v[1].Mostrar();
    }
}
