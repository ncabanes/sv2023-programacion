﻿using System;

class VentanaDeAviso
{
    private int x, y, anchura, altura;
    private string texto;

    public VentanaDeAviso() { }
    
    public VentanaDeAviso(int xInicial, int yInicial,
        int ancho, int alto, string textoMostrar)
    {
        X = xInicial;
        Y = yInicial;
        Anchura = ancho;
        Altura = alto;
        Texto = textoMostrar;
    }

    public int X
    {
        get { return x; }
        set { x = value; }
    }

    public int Y
    {
        get { return y; }
        set { y = value; }
    }

    public int Anchura
    {
        get { return anchura; }
        set { anchura = value; }
    }

    public int Altura
    {
        get { return altura; }
        set { altura = value; }
    }

    public string Texto
    {
        get { return texto; }
        set { texto = value; }
    }

    public virtual void Mostrar()
    {
        for (int fila = 0; fila < altura; fila++)
        {
            for (int columna = 0; columna < anchura; columna++)
            {
                if (fila == 0 || fila == altura - 1
                    || columna == 0 || columna == anchura - 1)
                {
                    Console.SetCursorPosition(x + columna, y + fila);
                    Console.Write("*");
                }
            }
        }
        Console.SetCursorPosition(
            x + anchura / 2 - texto.Length / 2,
            y + altura / 2);
        Console.WriteLine(texto);
    }
}
