﻿/* 145. Crea una nueva versión del proyecto de las clases VentanaDeAviso 
 * VentanaDeAvisoRellena (ejercicio 143), en la que las ventanas del programa
 * de ejemplo no sean variables independientes, sino que formen parte de un
 * array de "VentanaDeAviso". Es de esperar que la ventana rellena no se
 * dibuje correctamente, pero lo solucionaremos en el siguiente ejercicio.
 * 
 * VÍCTOR (...) */

class PruebaDeVentanaDeAviso
{
    static void Main()
    {
        VentanaDeAviso[] v = new VentanaDeAviso[2];

        v[0] = new VentanaDeAviso(40, 12, 30, 5,
            "Ventana sin rellenar");
        v[1] = new VentanaDeAvisoRellena(50, 6, 15, 5,
            "Ventana rellena");

        v[0].Mostrar();
        v[1].Mostrar();
    }
}
