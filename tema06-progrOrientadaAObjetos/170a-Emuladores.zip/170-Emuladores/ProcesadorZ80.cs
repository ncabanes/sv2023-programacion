﻿using System;

class ProcesadorZ80 : Procesador
{
    public ProcesadorZ80(float velocidad) : base (8, velocidad, 
        "A B C D E F H L")
    {
    }

    public override void MostrarOrdenes()
    {
        Console.Write("Z80: ");
        base.MostrarOrdenes();
    }

    public override string ToString()
    {
        return "Z80, " + base.ToString();
    }
}

