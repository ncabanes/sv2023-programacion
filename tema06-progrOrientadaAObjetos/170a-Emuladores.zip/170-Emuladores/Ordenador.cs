﻿class Ordenador
{
    protected Procesador procesador;
    protected Memoria memoria;
    protected string nombre;

    public string GetNombre() { return nombre; }

    public Ordenador (Procesador procesador, Memoria memoria, string nombre)
    {
        
        this.procesador = procesador;
        this.memoria = memoria;
        this.nombre = nombre;
    }
    public override string ToString()
    {
        return nombre + ", procesador " + procesador + ", " + memoria.GetTamanyo() 
            + " bytes de memoria"; ;
    }
}

