﻿using System;

abstract class Procesador
{
    protected byte bits;
    protected float velocidad;
    protected string registros;

    public byte GetBits() {  return bits; }
    public float GetVelocidad() {  return velocidad; }

    public override string ToString()
    {
        return bits + " bits, " + velocidad + " MHz";
    }

    public Procesador(byte bits, float velocidad, string registros)
    {
        this.bits = bits;
        this.velocidad = velocidad;
        this.registros = registros;
    }

    public void AnadirOrden(byte codigo, string ensamblador)
    {

    }

    public virtual void MostrarOrdenes()
    {
        Console.WriteLine("Lista de órdenes aún no disponible");
    }
}

