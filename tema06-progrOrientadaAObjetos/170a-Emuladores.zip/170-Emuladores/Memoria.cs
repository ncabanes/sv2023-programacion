﻿class Memoria
{
    protected int tamanyo;
    protected int[] arrayBytes;

    public int GetValorArray(int direccion) {  return arrayBytes[direccion]; }
    public int GetTamanyo() {  return tamanyo; }
    public void SetValorArray(int direccion, int valor)
    {
        arrayBytes[direccion] = valor;
    }

    public Memoria (int tamanyo)
    {
        this.tamanyo = tamanyo;
        this.arrayBytes = new int[tamanyo];
    }

    public Memoria(int tamanyo, byte tamanyoBusDatos): this(tamanyo)
    {
        // TO DO
    }
}

