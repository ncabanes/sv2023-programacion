﻿using System;

class Procesador6502 : Procesador
{
    public Procesador6502(float velocidad) : base(8, velocidad,
        "A X Y")
    {
    }

    public override void MostrarOrdenes()
    {
        Console.Write("6502: ");
        base.MostrarOrdenes();
    }

    public override string ToString()
    {
        return "6502, " + base.ToString();
    }
}

