﻿/* 138. Crea una clase "NaveEnemiga", que herede de "SpriteTextoColor", 
y cuyo constructor prefije el color a cyan y el carácter a "W". Crea 
una clase "NaveJugador", que herede de "SpriteTextoColor", y cuyo 
constructor prefije el color a amarillo y el carácter a "A". Muestra un 
objeto de cada clase desde "Main". */

// Iván (...), retoques menores por Nacho

class PruebaDeSprite
{
    static void Main()
    {
        ConsoleColor originalColor = Console.ForegroundColor;

        NaveEnemiga ne = new NaveEnemiga(10, 20);
        ne.Dibujar();

        NaveJugador nj = new NaveJugador(20, 10);
        nj.Dibujar();
        
        Console.ForegroundColor = originalColor;
    }
}
