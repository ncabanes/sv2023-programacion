﻿class NaveEnemiga : SpriteTextoColor
{
    public NaveEnemiga(int xInicial, int yInicial) 
    {
        x = xInicial; 
        y = yInicial;
        color = CambiarColor("cyan");
        caracter = 'W';
    }
}
