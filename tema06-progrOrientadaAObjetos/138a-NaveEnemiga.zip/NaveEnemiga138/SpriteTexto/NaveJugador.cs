﻿class NaveJugador : SpriteTextoColor
{
    public NaveJugador(int xInicial, int yInicial)
    {
        x = xInicial; 
        y = yInicial;
        color = CambiarColor("amarillo");
        caracter = 'A';
    }
}
