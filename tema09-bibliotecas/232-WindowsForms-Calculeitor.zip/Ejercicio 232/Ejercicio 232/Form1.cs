namespace Ejercicio_232
{
    public partial class Form1 : Form
    {
        public Form1()
        {

            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            lastResults.Clear();
            string result = num1.Text + "+" + num2.Text + "=" + Convert.ToString(Convert.ToInt32(num1.Text) + Convert.ToInt32(num2.Text));
            lastResults.Text = result;
            anyadirABarraLateral(result);
            clearNums();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            lastResults.Clear();
            string result = num1.Text + "x" + num2.Text + "=" + Convert.ToString(Convert.ToInt32(num1.Text) * Convert.ToInt32(num2.Text));
            lastResults.Text = result;
            anyadirABarraLateral(result);
            clearNums();
        }

        private void resta_Click(object sender, EventArgs e)
        {
            lastResults.Clear();
            string result = num1.Text + "-" + num2.Text + "=" + Convert.ToString(Convert.ToInt32(num1.Text) - Convert.ToInt32(num2.Text));
            lastResults.Text = result;
            anyadirABarraLateral(result);
            clearNums();
        }

        private void dividir_Click(object sender, EventArgs e)
        {
            lastResults.Clear();
            string result = num1.Text + "/" + num2.Text + "=" + Convert.ToString(Convert.ToInt32(num1.Text) / Convert.ToInt32(num2.Text));
            lastResults.Text = result;
            anyadirABarraLateral(result);
            clearNums();
        }
        private void clearNums()
        {
            num1.Clear();
            num2.Clear();
        }
        public void anyadirABarraLateral(string s1)
        {
            arrayResults.Text = arrayResults.Text + "\r\n" + s1;
        }
    }
}
