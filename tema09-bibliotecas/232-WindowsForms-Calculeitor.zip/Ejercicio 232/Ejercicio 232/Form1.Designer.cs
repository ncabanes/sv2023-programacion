﻿namespace Ejercicio_232
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            suma = new Button();
            resta = new Button();
            multi = new Button();
            dividir = new Button();
            num1 = new TextBox();
            num2 = new TextBox();
            lastResults = new TextBox();
            arrayResults = new TextBox();
            SuspendLayout();
            // 
            // suma
            // 
            suma.AccessibleRole = AccessibleRole.None;
            suma.Location = new Point(85, 189);
            suma.Name = "suma";
            suma.Size = new Size(30, 30);
            suma.TabIndex = 0;
            suma.Text = "+";
            suma.UseVisualStyleBackColor = true;
            suma.Click += button1_Click;
            // 
            // resta
            // 
            resta.Location = new Point(157, 189);
            resta.Name = "resta";
            resta.Size = new Size(30, 30);
            resta.TabIndex = 1;
            resta.Text = "-";
            resta.UseVisualStyleBackColor = true;
            resta.Click += resta_Click;
            // 
            // multi
            // 
            multi.Location = new Point(227, 189);
            multi.Name = "multi";
            multi.Size = new Size(30, 30);
            multi.TabIndex = 2;
            multi.Text = "X";
            multi.UseVisualStyleBackColor = true;
            multi.Click += button3_Click;
            // 
            // dividir
            // 
            dividir.Location = new Point(291, 189);
            dividir.Name = "dividir";
            dividir.Size = new Size(30, 30);
            dividir.TabIndex = 3;
            dividir.Text = "/";
            dividir.UseVisualStyleBackColor = true;
            dividir.Click += dividir_Click;
            // 
            // num1
            // 
            num1.Location = new Point(157, 104);
            num1.Name = "num1";
            num1.Size = new Size(100, 23);
            num1.TabIndex = 4;
            // 
            // num2
            // 
            num2.Location = new Point(157, 235);
            num2.Name = "num2";
            num2.Size = new Size(100, 23);
            num2.TabIndex = 5;
            // 
            // lastResults
            // 
            lastResults.Location = new Point(127, 347);
            lastResults.Name = "lastResults";
            lastResults.ReadOnly = true;
            lastResults.Size = new Size(170, 23);
            lastResults.TabIndex = 6;
            // 
            // arrayResults
            // 
            arrayResults.Location = new Point(361, 30);
            arrayResults.Multiline = true;
            arrayResults.Name = "arrayResults";
            arrayResults.ReadOnly = true;
            arrayResults.Size = new Size(190, 400);
            arrayResults.TabIndex = 7;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(563, 459);
            Controls.Add(arrayResults);
            Controls.Add(lastResults);
            Controls.Add(num2);
            Controls.Add(num1);
            Controls.Add(dividir);
            Controls.Add(multi);
            Controls.Add(resta);
            Controls.Add(suma);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button suma;
        private Button resta;
        private Button multi;
        private Button dividir;
        private TextBox num1;
        private TextBox num2;
        private TextBox lastResults;
        private TextBox arrayResults;
    }
}
